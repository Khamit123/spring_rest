create definer = root@localhost trigger manufactureinsert
    after insert
    on manufacture
    for each row
BEGIN
DECLARE a int;
DECLARE b int;
DECLARE c int;
DECLARE d int;
UPDATE product_storage p SET p.product_quantity = p.product_quantity + NEW.product_quantity WHERE p.product_id =New.product_id;
SELECT p.product_quantity INTO a FROM product_storage p WHERE p.product_id =New.product_id;
SELECT  count(*) into b  FROM `orderord` o WHERE o.product_id =NEW.product_id AND o.status="Производится" AND o.product_quantity <=a;
      simple_loop: LOOP
         IF b=0 THEN
            LEAVE simple_loop;
         END IF;
         SET b=b-1;
         SELECT o.order_id,o.product_quantity into c,d  FROM `order` o WHERE o.product_id =NEW.product_id AND o.status="Производится" AND o.product_quantity <=a LIMIT 1 offset b;
		set a=a-d;
        UPDATE `order` o set o.status="Ожидание доставки" where o.order_id=c;
   END LOOP simple_loop;
   UPDATE product_storage p SET p.product_quantity =a WHERE p.product_id =New.product_id;
END;

