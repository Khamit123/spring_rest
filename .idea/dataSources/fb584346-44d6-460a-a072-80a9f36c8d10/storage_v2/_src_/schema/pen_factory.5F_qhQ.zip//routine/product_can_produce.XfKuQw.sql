create
    definer = root@localhost function product_can_produce(pr_id int) returns int deterministic
begin
declare a ,min int;
DECLARE done INT DEFAULT FALSE;
declare mat_id,mat_qu int;
declare cur cursor for select m.material_id,cp.material_quntity
 from product as p
 inner join composition_of_product as cp using(product_id)
 inner join material as m using(material_id)
 where product_id=pr_id;
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
 open cur;
 set a=-1;
 my_loop: loop
 fetch cur into mat_id,mat_qu;
 select floor(sum(material_quantity)/mat_qu) from material_storage ms where material_id=mat_id group by material_id into min;
	if DONE then leave my_loop;
	end if;
	if a=-1 or min<a then set a=min;
    end if;
 end loop;
return a;
end;

