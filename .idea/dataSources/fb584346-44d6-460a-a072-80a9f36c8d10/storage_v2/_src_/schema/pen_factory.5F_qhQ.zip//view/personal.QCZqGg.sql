create definer = root@localhost view personal as
select `s`.`staff_id`                                                   AS `staff_id`,
       concat(`s`.`last_name`, ' ', `s`.`name`, ' ', `s`.`middle_name`) AS `ФИО`,
       `s`.`post`                                                       AS `Должность`,
       `d`.`name`                                                       AS `Отдел`,
       concat_ws(' ', `f`.`name`)                                       AS `Фабрика`
from ((`pen_factory`.`staff` `s` join `pen_factory`.`department` `d`
       on ((`s`.`department_id` = `d`.`department_id`))) left join `pen_factory`.`factory` `f`
      on ((`s`.`staff_id` = `f`.`staff_id`)))
where (`s`.`isworking` = 1);

