create definer = root@localhost trigger material_delivery_update
    before update
    on material_delivery
    for each row
begin
declare a int;
if new.order_status ='Выполнен'
 then 
 update material_storage set material_quantity=material_quantity+new.material_quantity where material_id=new.material_id;
end if;
end;

