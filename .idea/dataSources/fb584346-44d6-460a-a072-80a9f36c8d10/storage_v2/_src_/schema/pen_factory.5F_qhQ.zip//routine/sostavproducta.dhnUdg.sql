create
    definer = root@localhost procedure sostavproducta(IN prid int)
begin
 select m.name,concat(cp.material_quntity,m.units_of_measurement) as "Колво материала" from product as p inner join composition_of_product as cp using(product_id)
 inner join material as m using(material_id) where product_id=prid;
 end;

