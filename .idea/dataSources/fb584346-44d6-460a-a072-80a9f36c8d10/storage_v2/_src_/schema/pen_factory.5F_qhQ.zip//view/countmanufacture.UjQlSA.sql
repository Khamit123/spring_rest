create definer = root@localhost view countmanufacture as
select `p`.`name`                                                       AS `Продукт`,
       `convert_color`(`p`.`color`)                                     AS `Цвет`,
       `m`.`date_of_production`                                         AS `Дата производства`,
       `m`.`product_quantity`                                           AS `Количество`,
       `f`.`name`                                                       AS `Фабрика`,
       concat(`s`.`last_name`, ' ', `s`.`name`, ' ', `s`.`middle_name`) AS `ФИО`
from (((`pen_factory`.`manufacture` `m` join `pen_factory`.`product` `p`
        on ((`m`.`product_id` = `p`.`product_id`))) join `pen_factory`.`factory` `f`
       on ((`m`.`factory_id` = `f`.`factory_id`))) join `pen_factory`.`staff` `s`
      on ((`f`.`staff_id` = `s`.`staff_id`)));

