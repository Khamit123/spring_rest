create definer = root@localhost trigger updateorder
    before update
    on orderord
    for each row
begin
set new.price =productprice(NEW.product_id)*new.product_quantity;
end;

