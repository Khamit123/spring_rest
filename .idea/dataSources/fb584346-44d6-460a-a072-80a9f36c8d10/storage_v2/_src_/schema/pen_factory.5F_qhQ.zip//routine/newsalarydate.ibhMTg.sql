create
    definer = root@localhost procedure newsalarydate()
begin
	update staff set salary=salary*1.2 where (curent_time()-date_of_salary)/365>1;
 end;

