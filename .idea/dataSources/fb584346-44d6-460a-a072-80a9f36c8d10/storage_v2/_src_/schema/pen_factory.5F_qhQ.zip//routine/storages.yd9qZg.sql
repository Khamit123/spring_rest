create
    definer = root@localhost procedure storages()
begin
select m.name as Название ,ms.material_quantity Количество,ms.storage_name Название_склада,ms.adress Адресс_склада from material_storage ms inner join material m using( material_id)
union
select concat(p.name,' ',convert_color(p.color)),ps.product_quantity,ps.storage_name,ps.adress from product_storage ps  inner join product p using( product_id)
union
select m.name,'1',ms.storage_name,ms.adress from machine_storage ms  inner join machinery m using( machine_id);
end;

