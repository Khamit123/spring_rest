create
    definer = root@localhost function convert_color(c varchar(1)) returns varchar(30) deterministic
begin
declare color varchar(30);
if c='b'then set color ='Синий';
else if c='g'then set color ='Зелеёный';
else if c='r'then set color ='Красный';
else if c='w'then set color ='Белый';
end if;
end if;
end if;
end if;
return color;
end;

