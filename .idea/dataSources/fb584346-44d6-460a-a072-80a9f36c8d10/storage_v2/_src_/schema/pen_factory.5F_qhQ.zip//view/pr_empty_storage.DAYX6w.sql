create definer = root@localhost view pr_empty_storage as
select `p`.`product_id` AS `ID`, `p`.`name` AS `Название`, `convert_color`(`p`.`color`) AS `Цвет`
from (`pen_factory`.`product_storage` `ps` join `pen_factory`.`product` `p` on ((`ps`.`product_id` = `p`.`product_id`)))
where (`ps`.`product_quantity` = 0)
union
select `pr`.`product_id`             AS `product_id`,
       `pr`.`name`                   AS `name`,
       `convert_color`(`pr`.`color`) AS `convert_color(pr.color)`
from `pen_factory`.`product` `pr`
where `pr`.`product_id` in
      (select `pen_factory`.`product_storage`.`product_id` from `pen_factory`.`product_storage`) is false;

